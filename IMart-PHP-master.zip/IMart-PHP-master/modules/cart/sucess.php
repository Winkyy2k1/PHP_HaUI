<?php 

echo "<script>alert('Chúc mừng bạn đã đặt hàng thành công')</script>";
redirect("?mod=cart", "order_detail");


?>

<a href="?mode=home&act=main">Quay lại trang chủ</a>