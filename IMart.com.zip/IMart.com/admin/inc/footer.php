<div id="footer-wp">
    <div class="wp-inner">
        <p id="copyright">2022 © Admin Theme by IMART.com  </p>
    </div>
</div>
</div>
</div>
</body>
</html>