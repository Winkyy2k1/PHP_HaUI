<?php

echo "Trang chưa được khởi tạo";

